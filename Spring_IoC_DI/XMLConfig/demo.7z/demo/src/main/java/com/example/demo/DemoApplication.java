package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

//@SpringBootApplication
//@ComponentScan
public class DemoApplication {
	public static void main(String[] args) {
		//SpringApplication.run(DemoApplication.class, args);
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		FirstBean firstBean = context.getBean(FirstBean.class);
		SecondBean secondBean = context.getBean(SecondBean.class);
		PrototypeBean prototypeBean = context.getBean(PrototypeBean.class);
		RequestScopeBean requestScopeBean = context.getBean((RequestScopeBean.class));
		//SpringApplication.run(DemoApplication.class, args);





	}
}
