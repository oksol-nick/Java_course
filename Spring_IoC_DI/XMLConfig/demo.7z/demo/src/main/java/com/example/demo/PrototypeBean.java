package com.example.demo;

public class PrototypeBean {



    public PrototypeBean() {
                System.out.println("Привет, я ПротоБин, я родился!");
    }
}
