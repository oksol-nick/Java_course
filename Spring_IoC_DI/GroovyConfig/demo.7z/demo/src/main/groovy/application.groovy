import com.example.demo.FirstBean
import com.example.demo.PrototypeBean
import com.example.demo.RequestScopeBean
import com.example.demo.SecondBean

beans {

    prototypeBean(PrototypeBean) {
        bean -> bean.scope = "prototype"
    }

    secondBean(SecondBean) {

        prototypeBean = prototypeBean
    }

    firstBean(FirstBean) {

        prototypeBean = prototypeBean
        secondBean = secondBean
    }

    requestScopeBean(RequestScopeBean) {
        bean -> bean.scope = "request"
    }
}