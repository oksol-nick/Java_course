package com.example.demo;

public class RequestScopeBean {
    public RequestScopeBean() {System.out.println("Привет, я РеквеСкоупБин!");
    }
}
